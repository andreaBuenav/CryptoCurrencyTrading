package com.globant.model.exceptions;

public class InsufficientFundsException extends RuntimeException{
}
