package com.globant.model.exceptions;

public class InsufficientCryptoException extends RuntimeException {
}
