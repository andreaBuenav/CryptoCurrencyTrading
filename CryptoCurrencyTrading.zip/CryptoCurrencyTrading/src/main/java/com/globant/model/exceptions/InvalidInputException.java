package com.globant.model.exceptions;

public class InvalidInputException extends RuntimeException {

}
